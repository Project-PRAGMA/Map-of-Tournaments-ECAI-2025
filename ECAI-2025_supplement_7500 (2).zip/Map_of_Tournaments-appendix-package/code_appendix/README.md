To start, you may want to create an empty virtualenv:
```
python3 -m venv venv
source venv/bin/activate
```

To replicate our experiments, you need to install the required packages::
```
pip install -e libs/mapel-core
pip install -e libs/mapel-elections
pip install -e libs/mapel-tournaments
pip install -r requirements.txt
```
You will also need to install the `nauty` package and add `nauty-gentourng` to your PATH. On Fedora, this can be done using:
```
sudo dnf install nauty
```

To generate plots from Figure 1, run the appropriate python script:
```
python3 fig1a.py
python3 fig1b.py
python3 fig1c.py
```

To generate data from Table 1 and correlation plots from Appendix D, run:
```
python3 tab1.py
```

To generate maps from Figure 2, run:
```
python3 runner.py --experiment_id size-7 --distance_id ged_blp --embedding_id mds --parallel --title "" --legend_pos
python3 runner.py --experiment_id size-7 --distance_id katz_cen --embedding_id mds --parallel --title "" --legend_pos
python3 runner.py --experiment_id size-12 --distance_id ged_blp --embedding_id mds --parallel --title "" --legend_pos
python3 runner.py --experiment_id size-12 --distance_id katz_cen --embedding_id mds --parallel --title "" --legend_pos
python3 runner.py --experiment_id ordinal-8 --distance_id ged_blp --embedding_id mds --parallel --title "" --legend_pos
python3 runner.py --experiment_id ordinal-8 --distance_id katz_cen --embedding_id mds --parallel --title "" --legend_pos
```

To generate distortion plots from Figure 3, run:
```
python3 feature-runner.py --experiment_id size-7 --embedding_id mds --distance_id ged_blp --parallel --cmap my_autumn_r --feature_id distortion --title "" --clean_feature --limits 1.03 2.63
python3 feature-runner.py --experiment_id size-7 --embedding_id mds --distance_id katz_cen --parallel --cmap my_autumn_r --feature_id distortion --title "" --clean_feature --limits 1.03 2.63
python3 feature-runner.py --experiment_id size-12 --embedding_id mds --distance_id ged_blp --parallel --cmap my_autumn_r --feature_id distortion --title "" --clean_feature --limits 1.03 2.63
python3 feature-runner.py --experiment_id size-12 --embedding_id mds --distance_id katz_cen --parallel --cmap my_autumn_r --feature_id distortion --title "" --clean_feature --limits 1.03 2.63
```

To generate colorings from Figures 4 and 5, run:
```
python3 feature-runner.py --experiment_id size-12 --embedding_id mds --distance_id ged_blp --parallel --cmap custom_r --feature_id copeland_winners_count --title "" --discrete
python3 feature-runner.py --experiment_id size-12 --embedding_id mds --distance_id ged_blp --parallel --cmap custom_r --feature_id top_cycle_winners_count --title "" --discrete
python3 feature-runner.py --experiment_id size-12 --embedding_id mds --distance_id ged_blp --parallel --cmap custom_r --feature_id slater_winners_count_parallel --title "" --discrete
python3 feature-runner.py --experiment_id size-12 --embedding_id mds --distance_id ged_blp --parallel --cmap custom_r --feature_id slater_winner_time_parallel --title ""
python3 feature-runner.py --experiment_id size-12 --embedding_id mds --distance_id ged_blp --parallel --cmap custom_r --feature_id single_elimination_win_chance --title ""
python3 feature-runner.py --experiment_id size-12 --embedding_id mds --distance_id ged_blp --parallel --cmap custom_r --feature_id single_elimination_winners_count_ilp --title "" --discrete
python3 feature-runner.py --experiment_id size-12 --embedding_id mds --distance_id ged_blp --parallel --cmap custom_r --feature_id single_elimination_winners_count_ilp_time_parallel --title ""
```

To generate maps from Appendix A:
```
python3 runner.py --experiment_id mov-12 --distance_id ged_blp --embedding_id mds --parallel --title "" --legend_pos
python3 runner.py --experiment_id mov-12 --distance_id katz_cen --embedding_id mds --parallel --title "" --legend_pos
```

To generate map from Appendix B:
```
python3 runner.py --experiment_id size-25 --distance_id katz_cen --embedding_id mds --parallel --title "" --legend_pos
```

For all invocations of `runner.py` and `feature-runner.py` you may want to use `--clean` and/or `--clean-feature` to recalculate everything from scratch.
