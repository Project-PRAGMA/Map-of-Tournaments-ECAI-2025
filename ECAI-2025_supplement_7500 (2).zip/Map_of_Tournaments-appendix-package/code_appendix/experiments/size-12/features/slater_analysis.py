import pandas as pd

df = pd.read_csv('slater_winner_time_parallel.csv', sep=';')

df['diff'] = df['value_std'] / df['value']

print(df['diff'].mean())
print(df['diff'].max())
