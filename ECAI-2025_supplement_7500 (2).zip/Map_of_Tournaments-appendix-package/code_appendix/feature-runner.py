import argparse
import builtins
import os
import signal
from inspect import getframeinfo, stack

import mapel.tournaments as mt
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from numpy import pi

signal.signal(signal.SIGINT, signal.SIG_DFL)

original_print = print


def print_wrap(*args, **kwargs):
    caller = getframeinfo(stack()[1][0])
    original_print("FN: ", caller.filename, "Line:", caller.lineno, "Func:", caller.function, "\n", *args,
                   **kwargs)


# builtins.print = print_wrap

cmap = LinearSegmentedColormap.from_list('my_autumn', ['firebrick', 'gold', 'forestgreen'])
mpl.colormaps.register(cmap=cmap)
cmap = LinearSegmentedColormap.from_list('my_autumn_r', list(reversed(['firebrick', 'gold', 'forestgreen'])))
mpl.colormaps.register(cmap=cmap)
cmap = LinearSegmentedColormap.from_list('custom', ['firebrick', 'gold', 'forestgreen', 'lightskyblue'])
mpl.colormaps.register(cmap=cmap)
cmap = LinearSegmentedColormap.from_list('custom_r',
                                         list(reversed(['firebrick', 'gold', 'forestgreen', 'lightskyblue'])))
mpl.colormaps.register(cmap=cmap)

parser = argparse.ArgumentParser(description='Run a tournament experiment.')
parser.add_argument('--experiment_id',
                    type=str,
                    required=True,
                    help=f'Experiment ID. Available experiments: {os.listdir("experiments")}')
parser.add_argument('--distance_id',
                    type=str,
                    required=True,
                    help=f'Distance ID. Available distances: {mt.TournamentSimilarity.list_distances()}')
parser.add_argument('--embedding_id', type=str, required=True, help=f'Embedding ID.')
parser.add_argument('--feature_id', type=str, required=True, help=f'Feature ID.')
parser.add_argument('--scale', type=str, default='linear', help=f'Scale.')
parser.add_argument('--cmap', type=str, default='binary', help=f'cmap.')
parser.add_argument('--rounding', type=int, default=2, help=f'Rounding.')
parser.add_argument('--discrete', action='store_true', help=f'Discrete.')
# Toggle
parser.add_argument('--parallel', action='store_true', help=f'Parallel.')
parser.add_argument('--clean', action='store_true', help=f'Clean.')
parser.add_argument('--clean_feature', action='store_true', help=f'Clean feature.')
parser.add_argument('--show', action='store_true', help=f'Show.')
parser.add_argument('--time', action='store_true', help=f'Whether to color by time instead.')
parser.add_argument('--subdir', type=str, default='images', help=f'Directory to save images.')
parser.add_argument('--title', type=str, default=None, help=f'Plot title.')
parser.add_argument('--tex', action='store_true', help=f'Use tex.')
parser.add_argument('--limits', type=float, nargs='+', help=f'Upper limit of the feature legend.')
args = parser.parse_args()

if args.discrete:
    args.rounding = 0

if args.subdir is not None:
    os.makedirs(os.path.join("images", args.subdir), exist_ok=True)

ex = mt.TournamentExperiment(experiment_id=args.experiment_id,
                             distance_id=args.distance_id,
                             embedding_id=args.embedding_id)
# ex.save_tournament_plots(path=f"graphs/{args.experiment_id}")
ex.compute_distances(distance_id=args.distance_id, parallel=args.parallel, clean=args.clean)
if ex.coordinates is None or args.clean:
    ex.embed_2d(embedding_id=args.embedding_id)
rotation_dict = {
    'ged_blp_size-7': -pi / 2 + pi / 20,
    'katz_cen_size-7': -pi / 4 + pi / 20,
    'ged_blp_ordinal-8': -pi / 4 - 2 * pi / 20,
    'katz_cen_ordinal-8': 3 * pi / 4 - pi / 20 + pi / 2,
    'ged_blp_size-12': -5 * pi / 6 - pi / 40,
    'katz_cen_size-12': -6 * pi / 4 + 9 * pi / 40,
    'ged_blp_mov-12': -5 * pi / 4 + pi / 30,
    'katz_cen_mov-12': -4 * pi / 4 - pi / 30,
    'katz_cen_size-25': pi / 9,
}
try:
    ex.rotate(rotation_dict[f"{args.distance_id}_{args.experiment_id}"])
except KeyError:
    pass
plt.rcParams.update({"text.usetex": args.tex})
if args.feature_id == 'ALL':
    for feature_id in mt.Features.registered_features.keys():
        if feature_id + '_parallel' in mt.Features.registered_features.keys() and args.parallel:
            continue
        ex.compute_feature(feature_id, clean=args.clean or args.clean_feature)
        ex.print_map_2d_colored_by_feature(
            show=args.show,
            saveas=f"{args.subdir}/{ex.experiment_id}-{args.distance_id}-{args.embedding_id}-{feature_id}.png",
            title=f"{feature_id} | {args.distance_id}, {args.embedding_id}"
            if args.title is None else args.title,
            feature_id=feature_id,
            column_id='time' if args.time else 'value',
            scale=args.scale,
            rounding=args.rounding,
            strech=args.limits,
            cmap=args.cmap)

else:
    ex.compute_feature(args.feature_id, clean=args.clean or args.clean_feature)
    ex.print_map_2d_colored_by_feature(
        show=args.show,
        saveas=f"{args.subdir}/{ex.experiment_id}-{args.distance_id}-{args.embedding_id}-{args.feature_id}.png",
        title=f"{args.feature_id} | {args.distance_id}, {args.embedding_id}"
        if args.title is None else args.title,
        feature_id=args.feature_id,
        column_id='time' if args.time else 'value',
        scale=args.scale,
        rounding=args.rounding,
        strech=args.limits,
        cmap=args.cmap)
