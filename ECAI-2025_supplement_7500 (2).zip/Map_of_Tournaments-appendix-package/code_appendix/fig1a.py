from multiprocessing import Pool

import matplotlib.pyplot as plt
from mapel.tournaments import TournamentCultures, TournamentSimilarity, helpers
from tqdm import tqdm


# Run the function in parallel
def run_parallel(func, work):
    with Pool() as p:
        res = list(tqdm(p.imap(func, work), total=len(work)))
    return res


@helpers.cache("")
def all_rps_distance_from_ordered(n=11):
    rps = TournamentCultures.get('all-rps')(n, 2000, {})
    ordered = TournamentCultures.get('ordered')(n, 1, {})[0]

    work = [(TournamentSimilarity.ged_blp, g, ordered) for g in rps]

    dist = run_parallel(TournamentSimilarity.parallel_runner, work)

    dist = [d[0] for d in dist]

    return dist


if __name__ == '__main__':
    dist = all_rps_distance_from_ordered(11)
    dist = [round(d) for d in dist]
    dist = {d: dist.count(d) for d in dist}
    print(dist)
    plt.bar(dist.keys(), dist.values(), color='gray')
    plt.yscale('log')
    plt.xticks(list(dist.keys()), fontsize=21)
    plt.yticks(fontsize=21)
    for x, y in dist.items():
        plt.text(x, y * 1.05, f'${y}$', ha='center', fontsize=12)
    plt.xlabel('GED from $T_{ord}$', fontsize=25)
    plt.ylabel('Count', fontsize=25)
    plt.tight_layout()
    plt.savefig('images/rps-to-ordered-size-11-dist-histogram.png')
    # plt.show()
