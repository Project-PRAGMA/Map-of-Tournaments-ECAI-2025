import signal

import mapel.tournaments as mt

# Make interrupt work with plots
signal.signal(signal.SIGINT, signal.SIG_DFL)

ex = mt.TournamentExperiment(experiment_id=f'size-12')
ex.print_correlation_between_distances(distance_id_1='ged_blp',
                                       distance_id_2='katz_cen',
                                       title="",
                                       label_size=25,
                                       ticks_size=21,
                                       alpha=0.01)
