import pickle
import signal
from multiprocessing import Pool

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from mapel.tournaments.objects.TournamentCultures import (ordered,
                                                          uniform_random)
from mapel.tournaments.objects.TournamentInstance import TournamentInstance
from mapel.tournaments.objects.TournamentSimilarity import (get_distance,
                                                            parallel_runner)
from scipy.stats import pearsonr, spearmanr
from tqdm import tqdm

# Make interrupt work with plots
signal.signal(signal.SIGINT, signal.SIG_DFL)

from inspect import getframeinfo, stack

original_print = print


def print_wrap(*args, **kwargs):
    caller = getframeinfo(stack()[1][0])
    original_print("FN:", caller.filename, "Line:", caller.lineno, "Func:", caller.function, ":::", *args,
                   **kwargs)


def load_distances(tournaments, distance_id, n, rep):
    try:
        dist = pickle.load(open(f"pickle/{distance_id}-{n}-{rep}.pickle", 'rb'))
    except:
        g_ord = TournamentInstance.raw(ordered(n, 1, {})[0])
        work = [(get_distance(distance_id), t, g_ord) for t in tournaments]
        print(f"Computing {distance_id} for n={n}")

        with Pool(100) as p:
            distances = tqdm(p.map(parallel_runner, work),
                             total=len(work),
                             desc=f"Computing {distance_id} for n={n}")
            dist = {}
        for i, d in enumerate(distances):
            dist[i] = d
        pickle.dump(dist, open(f"pickle/{distance_id}-{n}-{rep}.pickle", 'wb'))
    return dist


count = 100
reps = 10

# create empty df
ns = []
pearson = []
spearman = []
for n in range(4, 13):
    np.random.seed(42)
    for rep in range(reps):
        tournaments = [TournamentInstance.raw(t) for t in uniform_random(n, count, {})]
        ged_dist = load_distances(tournaments, 'ged_blp', n, rep)
        katz_dist = load_distances(tournaments, 'katz_cen', n, rep)
        d1 = [ged_dist[k] for k in sorted(ged_dist.keys())]
        d2 = [katz_dist[k] for k in sorted(katz_dist.keys())]

        ns.append(n)
        pearson.append(pearsonr(d1, d2)[0])
        spearman.append(spearmanr(d1, d2)[0])

df = pd.DataFrame({'Tournament size': ns, 'Pearson correlation': pearson, 'spearman': spearman})

# set theme to white background
#plt.rcParams.update({"text.usetex": True})
sns.set_theme(style="ticks")
p = sns.lineplot(data=df, x='Tournament size', y='Pearson correlation', errorbar='sd')
p.set_xlabel('Tournament size', fontsize=25)
p.set_ylabel('Pearson correlation', fontsize=25)
plt.xticks(fontsize=21)
plt.yticks(fontsize=21)
plt.tight_layout()
plt.savefig(f'images/pearson-spearman-uniform-to-ordered-lineplot-ged-katz-cen-count={count}-reps={reps}.png')
# plt.show()
