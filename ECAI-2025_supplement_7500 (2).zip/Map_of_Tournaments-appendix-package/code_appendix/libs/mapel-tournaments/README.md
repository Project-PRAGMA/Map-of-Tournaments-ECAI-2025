# Mapel-tournaments
This pacakge is a plugin for [mapel](https://pypi.org/project/mapel/) extending
it with necessary files to draw maps of Tournaments.

For the most recent version of mapel, visit its [git
repo](https://pypi.org/project/mapel/).

# Installation
TODO

For more complicated variants of installation, refer to the readme of mapel
[here](https://github.com/szufix/mapel).
