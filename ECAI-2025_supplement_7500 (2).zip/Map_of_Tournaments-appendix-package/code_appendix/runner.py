import argparse
import os
import signal

import mapel.tournaments as mt
import matplotlib.pyplot as plt
import numpy as np
from numpy import pi

signal.signal(signal.SIGINT, signal.SIG_DFL)

parser = argparse.ArgumentParser(description='Run a tournament experiment.')
parser.add_argument('--experiment_id',
                    type=str,
                    required=True,
                    help=f'Experiment ID. Available experiments: {os.listdir("experiments")}')
parser.add_argument('--distance_id',
                    type=str,
                    required=True,
                    help=f'Distance ID. Available distances: {mt.TournamentSimilarity.list_distances()}')
parser.add_argument('--embedding_id', type=str, required=True, help=f'Embedding ID.')
# Toggle
parser.add_argument('--parallel', action='store_true', help=f'Parallel.')
parser.add_argument('--clean', action='store_true', help=f'Clean.')
parser.add_argument('--clean_embed', action='store_true', help=f'Clean embed.')
parser.add_argument('--show', action='store_true', help=f'Show.')
parser.add_argument('--subdir', type=str, default='images', help=f'Directory to save images.')
parser.add_argument('--title', type=str, default=None, help=f'Plot title.')
parser.add_argument('--tex', action='store_true', help=f'Use tex.')
parser.add_argument('--legend_pos', action='store_true', help=f'Legend position.')
parser.add_argument('--seed', type=int, help=f'Seed.')
parser.add_argument('--no_legend', action='store_true', help=f'No legend.')
# parser.add_argument('--xlabel', type=str, help=f'Plot xlabel.')
# parser.add_argument('--ylabel', type=str, help=f'Plot ylabel.')
args = parser.parse_args()

if args.subdir is not None:
    os.makedirs(os.path.join("images", args.subdir), exist_ok=True)

ex = mt.TournamentExperiment(experiment_id=args.experiment_id, distance_id=args.distance_id)
ex.compute_distances(distance_id=args.distance_id, parallel=args.parallel, clean=args.clean)
if ex.coordinates is None or args.clean or args.clean_embed:
    np.random.seed(args.seed)
    ex.embed_2d(embedding_id=args.embedding_id)

rotation_dict = {
    'ged_blp_size-7': -pi / 2 + pi / 20,
    'katz_cen_size-7': -pi / 4 + pi / 20,
    'ged_blp_ordinal-8': -pi / 4 - 2 * pi / 20,
    'katz_cen_ordinal-8': 3 * pi / 4 - pi / 20 + pi / 2,
    'ged_blp_size-12': -5 * pi / 6 - pi / 40,
    'katz_cen_size-12': -6 * pi / 4 + 9 * pi / 40,
    'ged_blp_mov-12': -5 * pi / 4 + pi / 30,
    'katz_cen_mov-12': -4 * pi / 4 - pi / 30,
    'katz_cen_size-25': pi / 9,
}
try:
    ex.rotate(rotation_dict[f"{args.distance_id}_{args.experiment_id}"])
except KeyError:
    pass
pltparams = {}
if args.title is not None:
    pltparams['title'] = args.title
plt.rcParams.update({"text.usetex": args.tex})
try:
    ex.print_map(show=False,
                 saveas=f"{args.subdir}/{ex.experiment_id}-{args.distance_id}-{args.embedding_id}.png",
                 legend_pos=(1.3, 1.0) if args.legend_pos else None,
                 legend=not args.no_legend,
                 **pltparams)
except KeyError:
    ex.embed_2d(embedding_id=args.embedding_id)
    ex.print_map(show=False,
                 saveas=f"{args.subdir}/{ex.experiment_id}-{args.distance_id}-{args.embedding_id}.png",
                 legend_pos=(1.3, 1.0) if args.legend_pos else None,
                 **pltparams)
if args.show:
    ex.print_map(show=args.show, **pltparams)
